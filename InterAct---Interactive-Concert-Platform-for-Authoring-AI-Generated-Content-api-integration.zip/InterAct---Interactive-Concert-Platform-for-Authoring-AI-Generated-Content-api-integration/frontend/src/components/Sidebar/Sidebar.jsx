import { Container, Paper } from '@mui/material'
import React from 'react'

export const Sidebar = () => {
  return (
    <Paper>
        <Container>
            
        </Container>
    </Paper>
  )
}
